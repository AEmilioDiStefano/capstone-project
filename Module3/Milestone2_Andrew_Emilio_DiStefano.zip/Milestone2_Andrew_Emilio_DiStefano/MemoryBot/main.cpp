#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <map>
#include <algorithm>
#include "Rememberer.h"

// FIXME: Finish the main function.
int main() {
  Rememberer rememberer;

  rememberer.introduction();

  rememberer.conversation();

  return 0;
}
